/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.example.chatapp;

import java.util.ArrayList;
import java.util.List;


/**
 *
 * @author hifi
 */
public class MessageManager {
    
           private List<Message> messages;

    public MessageManager() {
        messages = MessageStorage.loadMessages();
    }

    // Send a new message
    public String sendMessage(String recipient, String text) {
        if (text == null || text.isEmpty()) {
            return "Message cannot be empty.";
        }
        if (text.length() > 250) {
            return "Message exceeds 250 characters.";
        }
        Message m = new Message(messages.size(), recipient, text);
        String result = m.sendMessageViaDialog(); // sends message and updates status
        messages.add(m);
        MessageStorage.saveMessages(messages);
        return result;
    }

    // Store message without sending
    public String storeMessage(String recipient, String text) {
        if (text == null || text.isEmpty()) {
            return "Message cannot be empty.";
        }
        if (text.length() > 250) {
            return "Message exceeds 250 characters.";
        }
        Message m = new Message(messages.size(), recipient, text);
        m.performAction(2); // store
        messages.add(m);
        MessageStorage.saveMessages(messages);
        return "Message stored successfully.";
    }

    // Delete a message by index
    public String deleteMessage(int index) {
        if (index < 0 || index >= messages.size()) {
            return "Invalid message index.";
        }
        messages.remove(index);
        MessageStorage.saveMessages(messages);
        return "Message deleted successfully.";
    }

    // Get list of all messages
    public List<Message> getAllMessages() {
        return new ArrayList<>(messages);
    }

    // Get list of stored messages
    public List<Message> getStoredMessages() {
        List<Message> stored = new ArrayList<>();
        for (Message m : messages) {
            if (m.getStatus() == Message.Status.STORED) {
                stored.add(m);
            }
        }
        return stored;
    }

    // Get total messages sent
    public int getTotalSentMessages() {
        return Message.returnTotalMessages(messages);
    }
}
