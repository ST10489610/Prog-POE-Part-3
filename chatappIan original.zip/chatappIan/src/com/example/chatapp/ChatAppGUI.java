/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.example.chatapp;

import javax.swing.*;
import javax.swing.border.LineBorder;
import java.awt.*;
import java.awt.event.*;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

/**
 *
@author hifi
*/
public class ChatAppGUI {

    // Rounded button class
    static class RoundedButton extends JButton {
        public RoundedButton(String text) {
            super(text);
            setFocusPainted(false);
            setContentAreaFilled(false);
            setBorderPainted(false);
            setForeground(Color.GREEN);
            setFont(new Font("Segoe UI", Font.BOLD, 14));
            setOpaque(false);
            setMargin(new Insets(8, 14, 8, 14));
        }

        @Override
        protected void paintComponent(Graphics g) {
            Graphics2D g2 = (Graphics2D) g.create();
            g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);

            // background
            g2.setColor(Color.BLACK);
            g2.fillRoundRect(0, 0, getWidth(), getHeight(), 25, 25);

            super.paintComponent(g);
            g2.dispose();
        }
    }

    // Fade-in helper for undecorated modal dialogs
    private static void fadeIn(final Window window) {
        try {
            window.setOpacity(0f);
        } catch (UnsupportedOperationException ignored) {
            return;
        }
        Timer timer = new Timer(20, null);
        timer.addActionListener(new ActionListener() {
            float opacity = 0f;
            @Override
            public void actionPerformed(ActionEvent e) {
                opacity += 0.05f;
                if (opacity >= 1f) {
                    window.setOpacity(1f);
                    ((Timer)e.getSource()).stop();
                } else {
                    window.setOpacity(Math.min(1f, opacity));
                }
            }
        });
        timer.start();
    }

    public static void main(String[] args) {
        Color bgColor = Color.BLACK;
        Color borderColor = new Color(0, 0, 80);
        Color textColor = Color.GREEN;
        Font modernFont = new Font("Segoe UI", Font.PLAIN, 16);

        UIManager.put("OptionPane.background", bgColor);
        UIManager.put("Panel.background", bgColor);
        UIManager.put("OptionPane.messageForeground", textColor);
        UIManager.put("OptionPane.border", new LineBorder(borderColor, 4));
        UIManager.put("Button.background", Color.BLACK);
        UIManager.put("Button.foreground", textColor);
        UIManager.put("OptionPane.minimumSize", new Dimension(500, 270));
        UIManager.put("Label.font", modernFont);
        UIManager.put("Button.font", modernFont);

        boolean exitProgram = false;

        while (!exitProgram) {
            login loginHandler = new login();

            // UPDATED welcome screen
            showWelcomeScreen();

            // UPDATED REGISTRATION intro
            showCenteredMessage("✨ Welcome to IMQuickChat.\nLet's set up your new account.");

            String loggedUsername = null;

            while (true) {
                String username = JOptionPane.showInputDialog(null,
                        "🟩 Enter a username (must include '_' and be 5 characters or fewer):");
                if (username == null) { exitProgram = true; break; }

                String password = JOptionPane.showInputDialog(null,
                        "🔐 Create your password (8+ chars, uppercase, number & symbol):");
                if (password == null) { exitProgram = true; break; }

                String cellphone = JOptionPane.showInputDialog(null,
                        "📞 Enter your cellphone (+27 format supported):");
                if (cellphone == null) { exitProgram = true; break; }

                String regMessage = loginHandler.registerUser(username.trim(), password, cellphone.trim());
                showCenteredMessage(regMessage);

                if (regMessage.equals("Registration successful.")) {
                    loggedUsername = username.trim();
                    break;
                }
            }

            if (exitProgram) break;

            showCenteredMessage("✨ Welcome, " + loggedUsername + "! IMQuickChat is ready for you.");

            List<Message> allMessages = MessageStorage.loadMessages();

            int messagesToEnter = 0;
            while (messagesToEnter <= 0) {
                String nm = JOptionPane.showInputDialog(null, "📨 How many messages would you like to send today?");
                if (nm == null) { exitProgram = true; break; }
                try {
                    messagesToEnter = Integer.parseInt(nm.trim());
                    if (messagesToEnter <= 0)
                        showCenteredMessage("⚠ Enter a number greater than zero.");
                } catch (NumberFormatException e) {
                    showCenteredMessage("❗ Please enter a valid number.");
                }
            }
            if (exitProgram) break;

            boolean quit = false;
            while (!quit) {
                String menu = """
📘 Choose an option:

1. Send messages

2. View previous messages

3. Logout
""";

                String choice = JOptionPane.showInputDialog(null, menu);
                if (choice == null) { quit = true; break; }

                switch (choice.trim()) {
                    case "1":
                        sendMessages(allMessages, messagesToEnter, bgColor);
                        break;

                    case "2":
                        viewRecentMessages(allMessages, bgColor);
                        break;

                    case "3":
                        quit = true;
                        break;

                    default:
                        showCenteredMessage("⚠ Choose one of the available options.");
                }
            }

            int exitChoice = JOptionPane.showOptionDialog(null,
                    "👋 Thanks for using IMQuickChat.\nSee you next time.",
                    "Exit",
                    JOptionPane.YES_NO_OPTION,
                    JOptionPane.INFORMATION_MESSAGE,
                    null,
                    new String[]{"🔄 Restart", "❌ Exit"},
                    "❌ Exit");

            if (exitChoice != 0) exitProgram = true;

        }

    }

    private static void sendMessages(List<Message> allMessages, int messagesToEnter, Color bgColor) {
        int remaining = messagesToEnter - allMessages.size();
        if (remaining <= 0) {
            showCenteredMessage("❗ You’ve already reached today’s message limit.");
            return;
        }

        for (int i = 0; i < remaining; i++) {
            String recipient = JOptionPane.showInputDialog(null,
                    String.format("📨 Recipient for message %d (use +27):", i + 1));
            if (recipient == null) break;

            String messageText = JOptionPane.showInputDialog(null, "💬 Type your message (max 250 chars):");
            if (messageText == null) break;

            if (messageText.length() > 250) {
                showCenteredMessage("⚠ Keep it under 250 characters.");
                i--;
                continue;
            }

            showCenteredMessage("✔ Message processed successfully!");

            Message m = new Message(allMessages.size(), recipient.trim(), messageText);
            String actionResult = m.sendMessageViaDialog();
            showCenteredMessage(actionResult);

            allMessages.add(m);
            MessageStorage.saveMessages(allMessages);

            showCenteredMessage(m.printMessageDetails());
        }

        int totalSent = Message.returnTotalMessages(allMessages);
        showCenteredMessage("📊 Total messages sent: " + totalSent);
    }

    private static void viewRecentMessages(List<Message> allMessages, Color bgColor) {
        if (allMessages.isEmpty()) {
            showCenteredMessage("⌛ No previous messages available.");
            return;
        }

        JDialog dialog = new JDialog((Frame) null, "Message History", true);
        dialog.setUndecorated(true);
        dialog.getRootPane().setBorder(BorderFactory.createLineBorder(new Color(0,0,80), 3));

        JPanel container = new JPanel(new BorderLayout());
        container.setBackground(Color.BLACK);

        JPanel titleBar = new JPanel(new BorderLayout());
        titleBar.setBackground(Color.BLACK);
        titleBar.setBorder(BorderFactory.createEmptyBorder(6, 10, 6, 10));

        JLabel header = new JLabel("📚 Message History");
        header.setForeground(Color.GREEN);
        header.setFont(new Font("Segoe UI", Font.BOLD, 16));
        titleBar.add(header, BorderLayout.WEST);

        JButton closeTop = new JButton("✖");
        closeTop.setFocusPainted(false);
        closeTop.setBorderPainted(false);
        closeTop.setContentAreaFilled(false);
        closeTop.setForeground(Color.GREEN);
        closeTop.setFont(new Font("Segoe UI", Font.BOLD, 14));
        closeTop.addActionListener(e -> dialog.dispose());
        titleBar.add(closeTop, BorderLayout.EAST);

        container.add(titleBar, BorderLayout.NORTH);

        JPanel mainPanel = new JPanel();
        mainPanel.setLayout(new BoxLayout(mainPanel, BoxLayout.Y_AXIS));
        mainPanel.setBackground(Color.BLACK);

        for (Message msg : allMessages) {
            JPanel msgPanel = new JPanel(new BorderLayout());
            msgPanel.setBackground(Color.BLACK);
            msgPanel.setBorder(BorderFactory.createLineBorder(new Color(0,0,80), 2));
            msgPanel.setPreferredSize(new Dimension(450, 100));

            JTextArea msgDetails = new JTextArea(msg.printMessageDetails());
            msgDetails.setEditable(false);
            msgDetails.setBackground(Color.BLACK);
            msgDetails.setForeground(Color.GREEN);
            msgDetails.setFont(new Font("Segoe UI", Font.PLAIN, 14));
            msgDetails.setLineWrap(true);
            msgDetails.setWrapStyleWord(true);

            msgPanel.add(msgDetails, BorderLayout.CENTER);

            JPanel buttonPanel = new JPanel(new FlowLayout(FlowLayout.RIGHT));
            buttonPanel.setBackground(Color.BLACK);

            RoundedButton deleteBtn = new RoundedButton("🗑 Delete");
            deleteBtn.addActionListener(e -> {
                int confirm = JOptionPane.showConfirmDialog(null,
                        "Delete this message?",
                        "Confirm Delete", JOptionPane.YES_NO_OPTION);
                if (confirm == JOptionPane.YES_OPTION) {
                    MessageStorage.deleteMessage(msg.getMessageId());
                    allMessages.remove(msg);
                    MessageStorage.saveMessages(allMessages);
                    dialog.dispose();
                    viewRecentMessages(allMessages, bgColor);
                }
            });
            buttonPanel.add(deleteBtn);

            if (msg.isStored()) {
                RoundedButton sendBtn = new RoundedButton("📤 Send");
                sendBtn.addActionListener(e -> {
                    msg.setStatus(Message.Status.SENT);
                    MessageStorage.updateMessageStatus(msg.getMessageId(), Message.Status.SENT);
                    MessageStorage.saveMessages(allMessages);
                    JOptionPane.showMessageDialog(null, "✔ Delivered successfully!");
                    dialog.dispose();
                    viewRecentMessages(allMessages, bgColor);
                });
                buttonPanel.add(sendBtn);
            }

            msgPanel.add(buttonPanel, BorderLayout.SOUTH);
            mainPanel.add(msgPanel);
            mainPanel.add(Box.createVerticalStrut(10));
        }

        JScrollPane scrollPane = new JScrollPane(mainPanel);
        scrollPane.setPreferredSize(new Dimension(520, 420));
        scrollPane.setBorder(BorderFactory.createEmptyBorder(8, 8, 8, 8));
        scrollPane.getVerticalScrollBar().setUnitIncrement(16);

        container.add(scrollPane, BorderLayout.CENTER);

        JPanel bottom = new JPanel(new FlowLayout(FlowLayout.CENTER));
        bottom.setBackground(Color.BLACK);
        RoundedButton closeBtn = new RoundedButton("Close");
        closeBtn.addActionListener(e -> dialog.dispose());
        bottom.add(closeBtn);
        container.add(bottom, BorderLayout.SOUTH);

        dialog.setContentPane(container);
        dialog.pack();
        dialog.setLocationRelativeTo(null);

        fadeIn(dialog);
        dialog.setVisible(true);

    }

    private static void showWelcomeScreen() {
        Color bgColor = Color.BLACK;
        Color textColor = Color.GREEN;
        Color borderColor = new Color(0, 0, 80);

        JDialog dialog = new JDialog((Frame) null, "Welcome", true);
        dialog.setUndecorated(true);
        dialog.getRootPane().setBorder(new LineBorder(borderColor, 5));

        JPanel panel = new JPanel(new BorderLayout());
        panel.setBackground(bgColor);
        panel.setPreferredSize(new Dimension(550, 300));

        JLabel title = new JLabel("✨ IMQuickChat ✨", SwingConstants.CENTER);
        title.setFont(new Font("Segoe UI", Font.BOLD, 36));
        title.setForeground(textColor);

        JLabel slogan = new JLabel("Instant. Clean. Yours.", SwingConstants.CENTER);
        slogan.setFont(new Font("Segoe UI", Font.PLAIN, 18));
        slogan.setForeground(textColor);

        panel.add(title, BorderLayout.CENTER);
        panel.add(slogan, BorderLayout.SOUTH);

        JPanel bottom = new JPanel(new FlowLayout(FlowLayout.CENTER));
        bottom.setBackground(bgColor);
        RoundedButton ok = new RoundedButton("OK");
        ok.addActionListener(e -> dialog.dispose());
        bottom.add(ok);
        panel.add(bottom, BorderLayout.NORTH);

        dialog.setContentPane(panel);
        dialog.pack();
        dialog.setLocationRelativeTo(null);

        fadeIn(dialog);
        dialog.setVisible(true);
    }

    private static void showCenteredMessage(String message) {
        JDialog dialog = new JDialog((Frame) null, "IMQuickChat", true);
        dialog.setUndecorated(true);
        dialog.getRootPane().setBorder(BorderFactory.createLineBorder(new Color(0,0,80), 4));

        JPanel panel = new JPanel(new BorderLayout());
        panel.setBackground(Color.BLACK);
        panel.setPreferredSize(new Dimension(520, 180));
        panel.setBorder(BorderFactory.createEmptyBorder(16, 16, 16, 16));

        JTextArea label = new JTextArea(message);
        label.setEditable(false);
        label.setLineWrap(true);
        label.setWrapStyleWord(true);
        label.setBackground(Color.BLACK);
        label.setForeground(Color.GREEN);
        label.setFont(new Font("Segoe UI", Font.PLAIN, 14));
        label.setOpaque(false);

        panel.add(label, BorderLayout.CENTER);

        JPanel bottom = new JPanel(new FlowLayout(FlowLayout.CENTER));
        bottom.setBackground(Color.BLACK);
        RoundedButton ok = new RoundedButton("OK");
        ok.addActionListener(e -> dialog.dispose());
        bottom.add(ok);
        panel.add(bottom, BorderLayout.SOUTH);

        dialog.setContentPane(panel);
        dialog.pack();
        dialog.setLocationRelativeTo(null);

        fadeIn(dialog);
        dialog.setVisible(true);
    }
}