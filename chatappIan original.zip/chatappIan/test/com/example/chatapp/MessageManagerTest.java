/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.example.chatapp;

import org.junit.Before;
import org.junit.Test;
import java.util.List;
import static org.junit.Assert.*;



/**
 *
 * @author hifi
 */
public class MessageManagerTest {
    
        private MessageManager manager;

    @Before
    public void setUp() {
        manager = new MessageManager();
        // Clear all messages before each test
        for (int i = manager.getAllMessages().size() - 1; i >= 0; i--) {
            manager.deleteMessage(i);
        }
    }

    @Test
public void testSendMessageSuccess() {
    // Send message via manager
    String result = manager.sendMessage("‪+27838968976‬", "Hello world");
    
    // Assert the result string
    assertEquals("Message successfully sent.", result);

    // Get all messages from manager
    List<Message> msgs = manager.getAllMessages();

    // There should be exactly 1 message
    assertEquals(1, msgs.size());

    // That message should be marked as SENT
    assertEquals(Message.Status.SENT, msgs.get(0).getStatus());
}

    @Test
    public void testStoreMessageSuccess() {
        String result = manager.storeMessage("+27838968976", "Stored message");
        assertEquals("Message stored successfully.", result);

        List<Message> stored = manager.getStoredMessages();
        assertEquals(1, stored.size());
        assertEquals(Message.Status.STORED, stored.get(0).getStatus());
    }

    @Test
    public void testDeleteMessage() {
        manager.sendMessage("+27838968976", "To delete");
        String delResult = manager.deleteMessage(0);
        assertEquals("Message deleted successfully.", delResult);
        assertEquals(0, manager.getAllMessages().size());
    }

    @Test
    public void testGetTotalSentMessages() {
        manager.sendMessage("+27838968976", "First");
        manager.storeMessage("+27838968976", "Second");
        manager.sendMessage("+27838968976", "Third");
        assertEquals(2, manager.getTotalSentMessages());
    }

    @Test
    public void testSendMessageTooLong() {
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < 251; i++) sb.append("A");
        String longMsg = sb.toString();
        String result = manager.sendMessage("+27838968976", longMsg);
        assertEquals("Message exceeds 250 characters.", result);
    }
}

    
    
